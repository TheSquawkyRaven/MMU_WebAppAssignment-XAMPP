<?php

function outputProgressTable ($number) {
	include ('progress-data.inc.php');
	
	echo	'<tbody>';
	echo	'<tr>';
	echo		'<td>'.${'id'.$number}.'</td>';
	echo		'<td>'.${'taskname'.$number}.'</td>';
	echo			'<td>'.${'category'.$number}.'</td>';
	echo			'<td>'.${'status'.$number}.'</td>';
	echo			'<td>'.${'startdate'.$number}.'</td>';
	echo			'<td>'.${'enddate'.$number}.'</td>';
	echo	'</tbody>';
}
 
?>