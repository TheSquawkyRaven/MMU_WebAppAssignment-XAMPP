<?php
  $id1 = "001";
  $taskname1 = 'Do nothing and die';
  $category1 = "Planning/Analyse";
  $status1 = "Haven't even start yet lol";
  $startdate1 = "Jan 1, 2022";
  $enddate1 = "Jan 31, 2022";
  
  $id2 = "002";
  $taskname2 = 'Still have no idea what to work lmao';
  $category2 = "Design/Diagram";
  $status2 = "ded";
  $startdate2 = "Feb 2, 2022";
  $enddate2 = "Feb 29, 2022";
?>
