<?php 
    $host = 'localhost';
    $username = 'root';
    $password = '';
    $database = 'fyp_planner';

    $con = new mysqli($host, $username, $password, $database) or die(mysqli_error);
?>