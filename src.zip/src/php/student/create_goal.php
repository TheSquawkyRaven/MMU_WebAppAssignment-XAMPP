<?php
    require '../connect.php';

    $task = $con->real_escape_string($_POST['task']);
    $category = $con->real_escape_string($_POST['category']);
	$status = $con->real_escape_string($_POST['status']);
	$startdate = $con->real_escape_string($_POST['startdate']);
	$enddate = $con->real_escape_string($_POST['enddate']);
    $id = $con->real_escape_string($_POST['id']);

    $sql = $con->query("INSERT INTO project(taskName, taskCategory, taskStatus, startDate, endDate) VALUES('$task', '$category', '$status', '$status', '$startDate', '$endDate', '$id')");

    if($sql) {
        echo 'true';
    }else {
        echo "INSERT INTO project(taskName, taskCategory, taskStatus, startDate, endDate) VALUES('$task', '$category', '$status', '$status', '$startDate', '$endDate', '$id')";
        echo $con->error;
    }
?>